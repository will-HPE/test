#!/bin/sh

# Setup environment variables used to by the install.sh script
export PREDIXMACHINE_VERSION="17.2.2"
export BOOTSTRAP_MOUNT_DIR="$HOME/bootstrap/"
export ARCH="x86_64"

env | sort