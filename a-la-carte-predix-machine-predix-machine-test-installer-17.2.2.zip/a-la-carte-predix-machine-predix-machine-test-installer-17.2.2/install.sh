#!/usr/bin/env bash

set -e
# installs predixmachine docker images in a debian environment

# find directory containing the project
#echo 'Finding directory containing this project'
#synced_folder=$(find $HOME \( ! -regex '.*/\..*' \) -type f -name 'install-bootstrap.sh')
#synced_path=$(dirname "$synced_folder") 
#export SYNCED_PATH="$synced_path"

source setup-env.sh

#
./scripts/tools/install-tools.sh

# install bootstrap
./scripts/predixmachine/install-bootstrap.sh


# install Mosquitto  
./scripts/predixmachine/install-mosquitto.sh
  
  
# install Predix machine agent
./scripts/predixmachine/install-predix-machine.sh --validate $PREDIXMACHINE_VERSION
  
# install subscriber app  
./scripts/predixmachine/install-subscriber-app.sh
  
# Install App to be tested
./scripts/predixmachine/install-app-to-test.sh

