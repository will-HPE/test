# a-la-carte-predix-machine

:warning: THIS IS WORK IN PROGRESS!!!
PROBABLY NOT WORKING YET!!!!


This Vagrant project helps you to easily provision and optionally enroll a dockerized Ubuntu 14.04 **Predix Machine 16.4.0** that you can use as testing environment when developing a Containerized Predix Machine End-to-
End Application.

## Dependencies
- VirtualBox. Version [4.3.12](http://download.virtualbox.org/virtualbox/4.3.12/VirtualBox-4.3.12-93733-Win.exe) recommended if you are running on Win 7.
- Vagrant [How to install](https://www.vagrantup.com/docs/installation/)
- Vagrant plugin vagrant-triggers [How to install](#installing-vagrant-plugin-vagrant-triggers) Only necessary if you want vagrant to automatically enroll/unenroll your predix machine VM in/from Edge Manager.
- [ubuntu-server-16.04-docker.box](https://devcloud.swcoe.ge.com/artifactory/HKUUW/boxes/ubuntu-server-16.04-docker.box). An ubuntu server **16.04** Vagrant box with docker already installed.



## Features
The provisioned VM has the following features:
- Allows for Networking customization
- docker pre-installed and ready to work.
- **Optional Automatic enrollment and unenrollment in Edge Manager**.
- Allows developers to quickly create and tear down testing predix machine environments.



 ![a-la-carte](https://github.build.ge.com/storage/user/8811/files/1c8fa784-c2eb-11e6-8eae-3d01eee9ab54)


 ## How to use it
Install VirtualBox and Vagrant. (See [Dependencies](#Dependencies) section)

### Using the Ubuntu Server 16.04 vagrant box
Download [ubuntu-server-16.04-docker.box](https://devcloud.swcoe.ge.com/artifactory/HKUUW/boxes/ubuntu-server-16.04-docker.box) from the Predix Avengers Artifactory repo. You will need to enter your Artifactory credentials (Usually your SSO credentials)<br/>
Open a bash terminal and go to the location of the downloaded box and run:
```bash
    vagrant box add --name ubuntu-server64-16.04-docker ubuntu-server-16.04-docker.box
```
This will install the box file in the local vagrant box store and will give it the name `ubuntu-server64-16.04-docker` recognizable in the vagrant context.

Next step is to create a Vagrantfile using the provided template.  The template file is located in the root of the a-la-carte folder.
```bash
cp Vagrantfile.template Vagrantfile
```
## Editing the Vagrantfile


### Enable/Disable Edge Manager auto enroll
Set variable `ENABLE_AUTO_ENROLL` to true if you want vagrant to automatically enroll your predix machine VM in Edge Manager upon provisioning when using `vagrant up` and unenroll it when destroying the VM using `vagrant destroy -f`. Vagrant will create a network interface, connected to a Host-Only network, and use its **MAC ADDRESS as the PREDIX MACHINE DEVICE ID** along with an automatically generated **PREDIX MACHINE DEVICE NAME** to enroll/unenroll the predix machine VM in Edge Manager.

You can verify that your VM got enrolled in Edge Manager by going to [https://kit-staging.edgemanager-qual.run.asv-pr.ice.predix.io](https://kit-staging.edgemanager-qual.run.asv-pr.ice.predix.io)

Set `ENABLE_AUTO_ENROLL` to false in you don't want vagrant to enroll/unenroll your VM in Edge Manager.

:warning: The auto unenroll feature requires vagrant plugin [vagrant-triggers](#installing-vagrant-plugin-vagrant-triggers) installed  
```ruby
# Enable/disable this Predix Machine Device auto enroll in Edge Manager'
ENABLE_AUTO_ENROLL = false
```
### Pick a name for your VM
Use a text editor to open the newly created `Vagrantfile`.
Go to the line shown and replace "my-testing-predix-machine" by the name you want your new Ubuntu 14.04 to have.
```ruby
  ############### Pick a machine name for this test box ####################
  config.vm.hostname = "my-testing-predix-machine"
  #################### NETWORKING SECTION. EDIT AS NEEDED ##################
```

### Forwarding ports to the physical machine
Next step is to forward the ports in your predix machine VM that you need to access externally.
Forwarding the VM ports will make them available to your host machine from localhost.

Go to the following section and add all the extra ports you need to forward.

```ruby
  ####### Add the ports you need to forward to your physical machine ############
  # Forwarding the ports will make them available to your host machine from localhost
  # For instance, to access the predix console of this predix machine from your PHYSICAL machine
  # in chrome go to https://localhost:8443/system/console

  # Forward Predix Machine console
  config.vm.network :forwarded_port, guest: 8443, host: 8443, id: 'http', auto_correct: true

  # Forward Mosquitto port
  config.vm.network :forwarded_port, guest: 1883, host: 1883, id: 'mqtt', auto_correct: true

  # To add a port to forward, use the following format:
  #  config.vm.network :forwarded_port, guest: <port in VM>, host: <port in physical machine>, id: <string - an alias>, auto_correct: true

```

#### Working at a GE facility
If you want your VM to have a GE ip address, uncomment the following line in your Vagrantfile:
```ruby
#### Uncomment line below if you want to bridge it to a physical Network.
#### Useful when you are in an GE facility ####
#### WARNING!!! Do not use if ENABLE_AUTO_ENROLL = true. It causes auto enroll to fail
 config.vm.network 'public_network', type: 'dhcp'
#####################################################################
```
:bomb: Do not use if `ENABLE_AUTO_ENROLL = true`. It causes auto enroll to fail

:warning: If you uncomment the previous line when working from home, your VM will most likely get an IP address from your home router.

### Defining the docker images to install
A series of self explanatory "place_here" folders give the user hints on where to place the `.tar.gz` files containing the docker images to install.

The images are installed in the order shown here.


#### 1. :open_file_folder: place_here_customized_predixmachine_image_to_load
Place in this folder the .tar.gz file corresponding to the Predix Machine image you want to install on this vagrant generated predix-machine.
Example:  [predixmachine-agent-x86_64-16.4.0.tar.gz](https://artifactory.predix.io/artifactory/PREDIX-EXT/predix-machine-package/docker-images/predixmachine-agent-x86_64/16.4.0/predixmachine-agent-x86_64-16.4.0.tar.gz).

- :exclamation: When `ENABLE_AUTO_ENROLL = true` Vagrant will only accept a file with name starting with the word `predixmachine-` , version `17.1.1` somewhere and extension `.tar.gz`otherwise no predix machine image will be installed and `vagrant up` will fail.

- :exclamation: When `ENABLE_AUTO_ENROLL = false` If no file with name starting with the word `predixmachine-` and extension `.tar.gz` is found, no predix machine image will be installed.

#### 2. :open_file_folder: place_here_mosquitto_image_to_load
Optionally, place in this folder the .tar.gz file of the mosquitto image you want to install on this vagrant generated predix-machine.

- :exclamation: If no file with name containing the word `mosquitto` and extension `.tar.gz` is found, no mosquitto image will be installed.


#### 3. :open_file_folder: place_here_subscriber_image_to_load
Optionally, place in this folder the .tar.gz file corresponding to the dockerized predix machine Subscriber Sample App that you can use as a test probe to peek on a MQTT topic
on this vagrant generated predix-machine.

- :exclamation: If no file with name with extension `.tar.gz` is found, no image will be installed.

#### 4. :open_file_folder: place_here_app_image_to_test
Optionally, place here the .tar.gz file of the dockerized predix machine App you want to test on this vagrant generated predix-machine.

- :exclamation: If no file with name with extension `.tar.gz` is found, no image will be installed.


### Spin up your VM
Once you are done tailoring your Vagrantfile and placing the `tar.gz` files of the images you want installed, you are ready to tell vagrant to provision a new Predix Machine.

Open a new Bash terminal and go to the folder where your Vagrantfile is and run
```bash
vagrant up
```
> :cherries: When `ENABLE_AUTO_ENROLL = true`
vagrant to automatically enroll your predix machine VM in Edge Manager upon provisioning when using `vagrant up`.

### ssh to your newly created predix machine
To open an ssh session to your new predix machine run the following command.  This is a great way to execute docker commands on the remote image from your development desktop.
```bash
vagrant ssh
```

### Destroying your VM
To destroy your VM type:
:warning:  If you are in a ssh terminal session, you must type 'exit' from your ssh session to return to your bash terminal before being able to execute the vagrant destroy command.
```bash
vagrant destroy -f
```
> :cherries: When `ENABLE_AUTO_ENROLL = true`
vagrant to automatically unenroll your predix machine VM in Edge Manager before destroying it with `vagrant destroy -f`.

## How to spin up multiple predix machines
Spinning up other predix machine instances is very easy. All you have to do is:

Copy the folder containing your vagrantfile to a new one using the following command
```bash
cp <folder-containing-your-vagrantfile>/ <new-folder>/
```
Next, `cd` to your `<new-folder>` and remove the `.vagrant` cache folder
```bash
 rm -rf <new-folder>/.vagrant/
```
:warning: Make sure you remove the `.vagrant` cache otherwise you'll get the following error message **the first time you try to spin up** your new instance

```bash
$ vagrant up
Bringing machine 'default' up with 'virtualbox' provider...
==> default: Machine already provisioned. Run `vagrant provision` or use the `--provision`
==> default: flag to force provisioning. Provisioners marked to run always will still run.
```

Next, change the config.vm.hostname property in your Vagrantfile so it's unique from the image you just cloned it from.

To spin up your new Predix Machine instance

```bash
cd <new-folder>
vagrant up
```

## Accesing the Predix Machine resources

If you forwarded the ports:
 - The Predix machine console can be accessed from https://localhost:8443/system/console.
 - The Mosquitto server can be accessed at tcp://localhost:1883

:cherries: When spinning up multiple VM's, Vargrant is smart enough to resolve port conflicts so be sure to note the new port numbers when spinning up the image so you can access the Predix machine resources with the correct port.

## Installing Vagrant plugin vagrant-triggers
To install this plugin, run the following command in a terminal
```bash
vagrant plugin install vagrant-triggers
```
If you get the following error after running the vagrant command (Thanks GE proxy!!! :poop:)
```
$ vagrant plugin install vagrant-triggers
Installing the 'vagrant-triggers' plugin. This can take a few minutes...
Bundler, the underlying system Vagrant uses to install plugins,
reported an error. The error is shown below. These errors are usually
caused by misconfigured plugin installations or transient network
issues. The error from Bundler is:

Could not verify the SSL certificate for https://gems.hashicorp.com/.
There is a chance you are experiencing a man-in-the-middle attack, but most likely your system doesn't have the CA certificates needed for verification. For information about OpenSSL certificates, see http://bit.ly/ruby-ssl. To connect without using SSL, edit your Gemfile sources and change 'https' to 'http'.

Warning: this Gemfile contains multiple primary sources. Using `source` more than once without a block is a security risk, and may result in installing unexpected gems. To resolve this warning, use a block to indicate which gems should come from the secondary source. To upgrade this warning to an error, run `bundle config disable_multisource true`.Retrying fetcher due to error (2/4): Bundler::Fetcher::CertificateFailureError Could not verify the SSL certificate for https://gems.hashicorp.com/.
There is a chance you are experiencing a man-in-the-middle attack, but most likely your system doesn't have the CA certificates needed for verification. For information about OpenSSL certificates, see http://bit.ly/ruby-ssl. To connect without using SSL, edit your Gemfile sources and change 'https' to 'http'.Retrying fetcher due to error (3/4): Bundler::Fetcher::CertificateFailureError Could not verify the SSL certificate for https://gems.hashicorp.com/.
There is a chance you are experiencing a man-in-the-middle attack, but most likely your system doesn't have the CA certificates needed for verification. For information about OpenSSL certificates, see http://bit.ly/ruby-ssl. To connect without using SSL, edit your Gemfile sources and change 'https' to 'http'.Retrying fetcher due to error (4/4): Bundler::Fetcher::CertificateFailureError Could not verify the SSL certificate for https://gems.hashicorp.com/.
There is a chance you are experiencing a man-in-the-middle attack, but most likely your system doesn't have the CA certificates needed for verification. For information about OpenSSL certificates, see http://bit.ly/ruby-ssl. To connect without using SSL, edit your Gemfile sources and change 'https' to 'http'.

```
You need to add the GE certificates to the vagrant's certificate store. Do the following.

Create the following environment variables:
```
http_proxy=http://sjc1intproxy02.crd.ge.com:8080
https_proxy=http://sjc1intproxy02.crd.ge.com:8080
```

Go to `[Vagrant installation path]\embedded\cacert.pem`. In Windows the Vagrant installation path is usually `C:\HashiCorp\Vagrant`.

Paste the contents of files [GE_External_Certificate1.pem](https://devcloud.swcoe.ge.com/artifactory/HKUUW/GE_External_Certificate1.pem) and [GE_External_Certificate2.pem](https://devcloud.swcoe.ge.com/artifactory/HKUUW/GE_External_Certificate2.pem) into the bottom of the file.
Try installing the vagrant plugin again.
