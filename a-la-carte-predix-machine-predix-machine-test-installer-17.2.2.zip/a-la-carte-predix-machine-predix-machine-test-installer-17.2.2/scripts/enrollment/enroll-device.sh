#!/usr/bin/env bash
#
# Enrolls this device in Edge Manager.
# The Predix Machine DEVICE ID used to enroll the device is resolved based on the MAC ADDRESS of the interface passed as parameter
# The DEVICE NAME used to enroll the device is the env var HOSTNAME.
# When parameter -r, --remove is specified, the device is UNENROLLED from Edge Manager
#
#

package="enroll-device"
interface=""
mac_address=""
env_var_name=""
unenroll_device=""

function displayHelp {
    # show the Tomcat log
    echo "$package - script used to enroll a Predix Machine Device in Edge Manager."
                        echo " The Predix Machine DEVICE ID used to enroll the device is generated based on the MAC ADDRESS of the interface passed as parameter"
                        echo " The DEVICE NAME used to enroll the device is the env var HOSTNAME"
                        echo " "
                        echo "$package interface [options]"
                        echo " "
                        echo "options:"
                        echo "-h, --help                   show brief help"
                        echo "-r  --remove                 cleans up enrollment of device from Edge Manager"
                        exit 0
}

if [ $# -eq 0 ]; then
    displayHelp
    exit 1
else
    interface=
fi
while test $# -gt 0; do
        case "$1" in
                -h|--help)
                        displayHelp ;;


                -r|--remove)
                        unenroll_device="TRUE"
                        shift
                        ;;

                -*)
                        echo "Unknown option '$1'. Exiting..." >&2
                        exit 1
                        ;;
                *)
                        if test $# -gt 0; then
                                interface=$1
                        else
                                echo "no interface name specified. Cannot resolve Predix Machine DEVICE ID" >&2
                                exit 1
                        fi
                        shift
                        ;;
        esac
done

if [ -z "$interface" ]; then
    echo "Error: no network interface name specified. Cannot generate DEVICE ID"
    exit 1
fi
echo "Finding MAC ADDRESS..."
mac_address=$(bash find-mac-address.sh "$interface")
echo "MAC ADDRESS for interface $interface found: $mac_address"

if [ -z "$unenroll_device" ]; then
    echo "Starting Auto enroll of device with DEVICE ID: $mac_address ..."
    python auto_enroll_certificate.py $mac_address
    echo "Done running Auto enroll of device with DEVICE ID: $mac_address ..."
else
    echo "Starting UNenroll of device with DEVICE ID: $mac_address ..."
    python enroll_cleanup.py $mac_address
    echo "Done UNenrolling device with DEVICE ID: $mac_address ..."
fi
