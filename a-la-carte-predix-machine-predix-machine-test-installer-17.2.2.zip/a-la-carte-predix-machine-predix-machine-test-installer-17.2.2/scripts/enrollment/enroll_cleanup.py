#!/usr/bin/env python
# ------------------------------------------------------------------------------
# Date         Version Build Author                       Comments
# 06-Jan-2017  001     001   Mike Williams/Alex Judkowicz US60400 - Initial coding
# 08-Jan-2017  001     002   Mike Williams/Alex Judkowicz US60400 - Completion of Auto Enrollment Feature
#
# Script called by the predix mahine in order to start the devicecertificate
# enrollment process
#
# example: python test.py abcd test2
#          where 'abcd' is the device Id and 'test2' is the device name
#-------------------------------------------------------------------------------
# Generic shebang line: affects which Python version is used on Unix and can
# be used to pass parameters to the interpreter in Windows
#-------------------------------------------------------------------------------
#-------------------------------------------------------------------------------
# Import required Python libraries.
# Command to install them: python -m pip install <PackageName>
#-------------------------------------------------------------------------------

import sys
import requests
import json

#-------------------------------------------------------------------------------
# Get a new oauth token for our edgemanger client
#
# TODO: Is hard-coded zone and client secret OK??
#-------------------------------------------------------------------------------
print ("---------- Getting Access token -----------")
url1 = 'https://2ad55d9e-716a-4254-a1d9-7a2474a36515.predix-uaa.run.asv-pr.ice.predix.io/oauth/token'
headers1 = {'content-type': 'application/x-www-form-urlencoded'}
data1 = {"grant_type": "client_credentials","client_id": "kit-staging-app-client","client_secret": "9ZhHYAe5ax8URGy"}
response1 = requests.post(url1, data=data1, headers=headers1)
auth_token = response1.json()["token_type"] + " " + response1.json()["access_token"]
print ("---------- Done Getting Access token --------------")
#print (response1.text)
#print (auth_token)

#-------------------------------------------------------------------------------
# Delete a device in EdgeManager
#-------------------------------------------------------------------------------
did = sys.argv[1]

print ("---------- Deleting Device with ID: " + str(did) + "-----------")
url2 = 'https://kit-staging.edgemanager-qual.run.asv-pr.ice.predix.io/svc/device/v1/device-mgmt/devices/' + did
headers2 = {'content-type': 'application/json','Authorization': auth_token}
response2 = requests.delete(url2, data=None, headers=headers2) #dumps used to encode into a json object

if response2.status_code == 204:
    print ("---------- Successfully Deleted Device with ID: " + str(did) + "-----------")
else:
    print ("---------- Failed to Delete Device with ID: " + str(did) + "-----------")
    print ("---------- Status: " + str(response2.status_code) + "----------")
    print ("---------- Error Message: " + response2.text + "---------- ")
