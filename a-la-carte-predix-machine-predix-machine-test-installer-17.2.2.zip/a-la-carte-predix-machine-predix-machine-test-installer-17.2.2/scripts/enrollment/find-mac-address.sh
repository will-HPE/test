#!/usr/bin/env bash
#
# Gets the MAC ADDRESS of the interface passed as parameter.
#
# 

package="find-mac-address"
interface=""
mac_address=""

function displayHelp {
    # show the Tomcat log
    echo "$package - script used to find the MAC ADDRESS of the network interface passed as parameter"
                        echo " "
                        echo "$package interface [options]"
                        echo " "                         
                        echo "options:"
                        echo "-h, --help                   show brief help"                                                 
                        exit 0                                            
}

if [ $# -eq 0 ]; then
    displayHelp
    exit 1
else
    interface=
fi
while test $# -gt 0; do
        case "$1" in
                -h|--help)
                        displayHelp ;;

                -*)
                        echo "Unknown option '$1'. Exiting..." >&2
                        exit 1
                        ;;
                *)                        
                        if test $# -gt 0; then
                                interface=$1                                
                        else
                                echo "no network interface name specified" >&2
                                exit 1
                        fi
                        shift
                        ;;
        esac
done

if [ -z "$interface" ]; then
    echo "Error: no network interface name specified."
    exit 1
fi

mac_address=$(ifconfig "$interface" | grep -o -E '([[:xdigit:]]{1,2}:){5}[[:xdigit:]]{1,2}')
mac_address=$(sed 's/[\/\:]//g' <<< $mac_address)
echo $mac_address
