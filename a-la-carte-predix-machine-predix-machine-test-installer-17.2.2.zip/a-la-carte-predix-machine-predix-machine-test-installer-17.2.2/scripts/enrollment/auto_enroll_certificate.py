#!/usr/bin/env python
#------------------------------------------------------------------------------
# Date         Version Build Author                       Comments
# 06-Jan-2017  001     001   Mike Williams/Alex Judkowicz US60400 - Initial coding
# 08-Jan-2017  001     002   Mike Williams/Alex Judkowicz US60400 - Completion of Auto Enrollment Feature
#
# Script called by the predix mahine in order to start the devicecertificate
# enrollment process
#
# example: python test.py abcd test2
#          where 'abcd' is the device Id and 'test2' is the device name
#-------------------------------------------------------------------------------
# Generic shebang line: affects which Python version is used on Unix and can
# be used to pass parameters to the interpreter in Windows
#-------------------------------------------------------------------------------
#-------------------------------------------------------------------------------
# Import required Python libraries.
# Command to install them: python -m pip install <PackageName>
#-------------------------------------------------------------------------------

import sys
import requests
import json
import string
import random
import time


#-------------------------------------------------------------------------------
# Validate that the device has been created and the status says "Enrolled" or "Unreachable - Enrolled"
#-------------------------------------------------------------------------------
def validateEnrollment( did, auth_token ):
    validated = 0
    url4 = 'https://kit-staging.edgemanager-qual.run.asv-pr.ice.predix.io/svc/device/v1/device-mgmt/devices/' + str(did) + "/status"
    headers4 = {'content-type': 'application/json','Authorization': auth_token}
    response4 = requests.get(url4, headers=headers4) #dumps used to encode into a json object

    print (response4.text)
    print (response4.status_code)

    if(response4.status_code == 200):
        if (response4.json()["device_status"] == "Enrolled") :
            validated = 1
        elif(response4.json()["device_status"] == "Unreachable - Enrolled") :
            validated = 2

    return validated

#-------------------------------------------------------------------------------
# Get a new oauth token for our edgemanger client
#
# TODO: Is hard-coded zone and client secret OK??
#-------------------------------------------------------------------------------
print ("---------- Getting Access token -----------")
url1 = 'https://2ad55d9e-716a-4254-a1d9-7a2474a36515.predix-uaa.run.asv-pr.ice.predix.io/oauth/token'
headers1 = {'content-type': 'application/x-www-form-urlencoded'}
data1 = {"grant_type": "client_credentials","client_id": "kit-staging-app-client","client_secret": "9ZhHYAe5ax8URGy"}
response1 = requests.post(url1, data=data1, headers=headers1)
auth_token = response1.json()["token_type"] + " " + response1.json()["access_token"]

if response1.status_code == 200:
    print ("---------- Successfully Got Token -----------")
else:
    print ("---------- Failed to Get the Token -----------")
    exit()

#print (response1.text)
#print (auth_token)

#-------------------------------------------------------------------------------
# Create a new device in EdgeManager
#
# TODO:
# What if the device aleady exists? Is it ok to hard-code the base URL2?
# where are the technicianId and other device attributes coming from?
#-------------------------------------------------------------------------------

# Uses random numbers to generate a unique device id(if not provided in args) and device name.  This completes this script to be fully automated.
# You can use the below to lines if you prefer to pass in the parameters as arguments.  Make sure to comment the random
# generation lines if you do!
randomLength = 10
if len(sys.argv) > 2:
    dname = sys.argv[2]
    did = sys.argv[1]
elif len(sys.argv) > 1:
    did = sys.argv[1]
    dname = 'test_' + ''.join(random.SystemRandom().choice(string.ascii_lowercase + string.digits) for _ in range(5))
else:
    did = 'd' + ''.join(random.SystemRandom().choice(string.ascii_lowercase + string.digits) for _ in range(randomLength))
    dname = 'test_' + ''.join(random.SystemRandom().choice(string.ascii_lowercase + string.digits) for _ in range(5))

print ("---------- Creating Device (" + str(dname) + ") With ID (" + str(did) + ") in EdgeManager -----------")
url2 = 'https://kit-staging.edgemanager-qual.run.asv-pr.ice.predix.io/svc/device/v2/device-mgmt/devices'
headers2 = {'content-type': 'application/json','Authorization': auth_token}
data2 = {"config": {"dockerEnabled": "true","simulated": "true","technicianId": "michael_williams"},
         "did": did,"modelID": "MiniFieldAgent","name": dname,"sharedSecret": "secret"}
response2 = requests.post(url2, data=json.dumps(data2), headers=headers2) #dumps used to encode into a json object

if (response2.status_code == 200 or response2.status_code == 201):
    print ("---------- Status: " + str(response2.status_code) + " ----------")
    print ("---------- Successfully Created the Device -----------")
else:
    print ("---------- Failed to Create Device with ID: " + str(did) + " -----------")
    print ("---------- Status: " + str(response2.status_code) + " ----------")
    print ("---------- Error Message: " + response2.text + " ---------- ")
    sys.exit(1)

#Hit techconsole (localhost:8443) and provide did, edgeManagerURL, and sharedSecret
#-------------------------------------------------------------------------------
print ("---------- Enrolling Device -----------")
url3 = 'https://127.0.0.1:8443/enroll/enrollCert'
# headers3 = {'content-type': 'application/json','Authorization': 'Basic cHJlZGl4OnByZWRpeDJtYWNoaW5l'}
headers3 = {'content-type': 'application/json','Authorization': 'Basic cHJlZGl4OnByZWRpeDJtYWNoaW5l'}
data3 = {
    "deviceId": did,
    "edgeManagerUrl": "https://kit-staging.edgemanager-qual.run.asv-pr.ice.predix.io",
    "sharedSecret": "secret"
}

response3 = requests.post(url3, data=json.dumps(data3), headers=headers3, verify=False) #dumps used to encode into a json object
print (response3.text)
print (response3.status_code)

count = 1
validated = 0
print("Contacting Edge Manager to check status of device with ID: " + str(did) + " and NAME: " + str(dname))
validated = validateEnrollment(did, auth_token)

if validated == 1:
    print("---------- Successfully Enrolled ----------")
elif validated == 2:
    print("---------- WARNING: Device Enrolled however EdgeManager is still trying to reach it ----------")
else:
    print("---------- ERROR: Not Enrolled Properly ----------")
