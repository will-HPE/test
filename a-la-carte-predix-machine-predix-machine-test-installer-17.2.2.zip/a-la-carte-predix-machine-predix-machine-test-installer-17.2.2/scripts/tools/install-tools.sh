#!/usr/bin/env bash
#
# Installs various tools.
#

sudo apt-get update 
sudo apt-get install -y unzip