
# find directory containing the project
#echo 'Finding directory containing this project'
#synced_folder=$(find $HOME \( ! -regex '.*/\..*' \) -type f -name 'install-bootstrap.sh')
#synced_path=$(dirname "$synced_folder") 
#export SYNCED_PATH="$synced_path"

#source $SYNCED_PATH/scripts/tools/export-var.sh

version_to_validate="$PREDIXMACHINE_VERSION"
bootstrapMountDirectory="$BOOTSTRAP_MOUNT_DIR"

cd scripts/enrollment
echo "Waiting for Predix_Machine cointainer to start..."
#predix_machine_container=$(docker ps -a | grep Predix_Machine 2> /dev/null)
predix_machine_proxy_config_file=""
 while [ -z "$predix_machine_proxy_config_file" ]; do
             sleep 0.5
             predix_machine_proxy_config_file=$(ls $bootstrapMountDirectory/containers/Predix_Machine/configuration/machine/org.apache.http.proxyconfigurator-0.config 2> /dev/null)
         done
echo "Editing file org.apache.http.proxyconfigurator-0.config to add and enable a proxy server"
sed -i '/\<proxy.host\>/c\proxy.host="proxy-src.research.ge.com"' $bootstrapMountDirectory/containers/Predix_Machine/configuration/machine/org.apache.http.proxyconfigurator-0.config
sed -i '/proxy.enabled/c\proxy.enabled=B"true"' $bootstrapMountDirectory/containers/Predix_Machine/configuration/machine/org.apache.http.proxyconfigurator-0.config
echo "Waiting for Predix_Machine cointainer to restart..."
wget --quiet --proxy=off --retry-connrefused --waitretry=15 --timeout=15 --no-check-certificate https://localhost:8443
echo "Predix_Machine cointainer seems to be up and running..."
echo "Runinng script enroll-device.sh <interface>"
bash enroll-device.sh enp0s8