
# find directory containing the project
#echo 'Finding directory containing this project'
#synced_folder=$(find $HOME \( ! -regex '.*/\..*' \) -type f -name 'install-bootstrap.sh')
#synced_path=$(dirname "$synced_folder") 
#export SYNCED_PATH="$synced_path"

#source $SYNCED_PATH/scripts/tools/export-var.sh

echo "----------------------------------------------------------------------------"
echo "              Installing subscriber image                     "
echo "----------------------------------------------------------------------------"

bootstrapMountDirectory="$BOOTSTRAP_MOUNT_DIR"

imagefile=$(ls place_here_subscriber_image_to_load/*.tar.gz 2> /dev/null)
if [ -z "$imagefile" ]; then
    echo "No .tar.gz file found. Nothing to install here."
else
    echo "Installing image $(basename $imagefile)"
    cp $imagefile $bootstrapMountDirectory
fi
