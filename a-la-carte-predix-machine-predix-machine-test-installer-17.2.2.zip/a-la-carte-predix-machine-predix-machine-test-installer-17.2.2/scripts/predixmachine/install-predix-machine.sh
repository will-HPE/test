#!/usr/bin/env bash
#
# Enrolls this device in Edge Manager.
# The Predix Machine DEVICE ID used to enroll the device is resolved based on the MAC ADDRESS of the interface passed as parameter 
# The DEVICE NAME used to enroll the device is the env var HOSTNAME. 
# When parameter -r, --remove is specified, the device is UNENROLLED from Edge Manager
#
# 
echo "----------------------------------------------------------------------------"
echo "                       Installing predix machine image                      "
echo "----------------------------------------------------------------------------"

# find directory containing the project
#echo 'Finding directory containing this project'
#synced_folder=$(find $HOME \( ! -regex '.*/\..*' \) -type f -name 'install-bootstrap.sh')
#synced_path=$(dirname "$synced_folder") 
#export SYNCED_PATH="$synced_path"

#source $SYNCED_PATH/scripts/tools/export-var.sh

package="install-predix-machine"
validate_version=""
version_to_validate="$PREDIXMACHINE_VERSION"
bootstrapMountDirectory="$BOOTSTRAP_MOUNT_DIR"


function displayHelp {
    # show the Tomcat log
    echo "$package - script used to install a Predix Machine Docker Image."
                        echo " The Predix Machine DEVICE ID used to enroll the device is generated based on the MAC ADDRESS of the interface passed as parameter"
                        echo " The DEVICE NAME used to enroll the device is the env var HOSTNAME"
                        echo " "
                        echo "$package [options]"
                        echo " "
                        echo "options:"
                        echo "-h, --help                   show brief help"                           
                        echo "-v, --validate [version]     Checks that the name of the image to install contains the version passed as parameter."                     
                        exit 0                        
}

function installImage(){
    
    cp $1 $bootstrapMountDirectory
    echo "Waiting for Predix_Machine container to start..."
    wget --quiet --proxy=off --retry-connrefused --waitretry=15 --timeout=15 --no-check-certificate https://localhost:8443
    echo "Predix_Machine container seems to be up and running..."
}
#if [ $# -eq 0 ]; then
#    displayHelp
#    exit 1

#fi
while test $# -gt 0; do
        case "$1" in
                -h|--help)
                        displayHelp ;;
                
                -v | --validate)
                        validate_version="true"
                        shift
                        if test $# -gt 0; then                                
                                version_to_validate=$1                                
                        else
                                echo "no version specified" >&2
                                exit 1
                        fi
                                                                                            
                        shift
                        ;;                                                       

                -*)
                        echo "Unknown option '$1'. Exiting..." >&2
                        exit 1
                        ;;                
        esac
done

if [ -z "$validate_version" ]; then
    # Check if image is predix machine
    imagefile=$(ls place_here_customized_predixmachine_image_to_load/predixmachine-*.tar.gz 2> /dev/null)
    if [ -z "$imagefile" ]; then
        echo "No predix machine image found. Nothing to install here."
    else
        echo "Installing predix machine image $(basename $imagefile)"
        installImage $imagefile
    fi
else
    echo "Checking for image version $version_to_validate"
    imagefile=$(ls place_here_customized_predixmachine_image_to_load/predixmachine-*"$version_to_validate"*.tar.gz 2> /dev/null)
    if [ -z "$imagefile" ]; then
        echo "No predix machine image version $version_to_validate found. Exiting."
        exit 1
    else
        echo "Installing predix machine image $(basename $imagefile)"
        installImage $imagefile
        exit 0
    fi
fi


