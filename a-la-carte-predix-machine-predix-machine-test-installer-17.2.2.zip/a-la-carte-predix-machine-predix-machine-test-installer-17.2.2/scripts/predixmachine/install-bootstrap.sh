#!/usr/bin/env bash
#
# Installs bootstrap docker image that is part of the Predix machine software stack
# 
#
# 

echo "----------------------------------------------------------------------------"
echo "              Installing predix machine bootstrap image                     "
echo "----------------------------------------------------------------------------"

# find directory containing the project
#echo 'Finding directory containing this project'
#synced_folder=$(find $HOME \( ! -regex '.*/\..*' \) -type f -name 'install-bootstrap.sh')
#synced_path=$(dirname "$synced_folder") 
#export SYNCED_PATH="$synced_path"

#source $SYNCED_PATH/scripts/tools/export-var.sh
env

package="install-bootstrap"
validate_version=""
version_to_validate="$PREDIXMACHINE_VERSION"
bootstrapMountDirectory="$BOOTSTRAP_MOUNT_DIR"


function displayHelp {
    # show the Tomcat log
    echo "$package - script used to the bootstrap docker image that is part of the Predix machine software stack."
                        echo " The Predix Machine DEVICE ID used to enroll the device is generated based on the MAC ADDRESS of the interface passed as parameter"
                        echo " The DEVICE NAME used to enroll the device is the env var HOSTNAME"
                        echo " "
                        echo "$package [options]"
                        echo " "
                        echo "options:"
                        echo "-h, --help                   show brief help"                           
                        echo "-v, --validate [version]     Checks that the name of the image to install contains the version passed as parameter."                     
                        exit 0                        
}

function installImage(){
    
   
    # load bootstrap into docker local store
    bootstrapfile=$1
    predixMachineSDKDir="$HOME/predixmachinesdk-$version_to_validate"  
    echo "Loading bootstrap $(basename $bootstrapfile) into docker"
    docker load -i $bootstrapfile

    # create <bootstrap mount directory>
    echo "creating bootstrap mount directory: $bootstrapMountDirectory"
    mkdir -p $bootstrapMountDirectory

    #validate sdk
    echo "Checking for sdk version $version_to_validate"
    sdkfile=$(ls place_here_predixmachine_sdk/*sdk*"$version_to_validate"*.zip 2> /dev/null)
    if [ -z "$sdkfile" ]; then
        echo "ERROR: No predix machine sdk version $version_to_validate found. Exiting."
        exit 1    
    fi

    # extract sdk
    rm -rf $predixMachineSDKDir
    unzip $sdkfile -d $HOME/

    # use sdk to install bootstrap
    bash $predixMachineSDKDir/utilities/containers/bootstrap/start_bootstrap.sh -d $bootstrapMountDirectory --arch $ARCH
    
}


#if [ $# -eq 0 ]; then
#    displayHelp
#    exit 1

#fi
while test $# -gt 0; do
        case "$1" in
                -h|--help)
                        displayHelp ;;
                
                -v | --validate)
                        validate_version="true"
                        shift
                        if test $# -gt 0; then                                
                                version_to_validate=$1                                
                        else
                                echo "no version specified" >&2
                                exit 1
                        fi
                                                                                            
                        shift
                        ;;                                                       

                -*)
                        echo "Unknown option '$1'. Exiting..." >&2
                        exit 1
                        ;;                
        esac
done


if [ -z "$validate_version" ]; then
    # Check if image is predix machine
    imagefile=$(ls place_here_bootstrap_image_to_load/predixmachine-bootstrap*.tar.gz 2> /dev/null)
    if [ -z "$imagefile" ]; then
        echo "ERROR: No predix machine bootstrap image found!!."
        exit 1
    else
        echo "Installing predix machine bootstrap image $(basename $imagefile)"
        installImage $imagefile
    fi
else
    echo "Checking for bootstrap image version $version_to_validate"
    imagefile=$(ls place_here_bootstrap_image_to_load/predixmachine-bootstrap*"$version_to_validate"*.tar.gz 2> /dev/null)
    if [ -z "$imagefile" ]; then
        echo "No predix machine bootstrap image version $version_to_validate found. Exiting."
        exit 1
    else
        echo "Installing predix machine bootstrap image $(basename $imagefile)"
        installImage $imagefile
        exit 0
    fi
fi

rm -rf $predixMachineSDKDir
