#!/usr/bin/env bash
#
# Installs bootstrap docker image that is part of the Predix machine software stack
# 
#
# 
echo "----------------------------------------------------------------------------"
echo "                          Installing Mosquitto image                        "
echo "----------------------------------------------------------------------------"

# find directory containing the project
#echo 'Finding directory containing this project'
#synced_folder=$(find $HOME \( ! -regex '.*/\..*' \) -type f -name 'install-bootstrap.sh')
#synced_path=$(dirname "$synced_folder") 
#export SYNCED_PATH="$synced_path"

#source $SYNCED_PATH/scripts/tools/export-var.sh

version_to_validate="$PREDIXMACHINE_VERSION"
bootstrapMountDirectory="$BOOTSTRAP_MOUNT_DIR"

imagefile=$(ls place_here_mosquitto_image_to_load/*mosquitto*.tar.gz 2> /dev/null)
if [ -z "$imagefile" ]; then
    echo "No mosquitto image found. Nothing to install here."
else
    echo "Installing mosquitto image $(basename $imagefile)"
    cp $imagefile $bootstrapMountDirectory

    
fi
