
# find directory containing the project
#echo 'Finding directory containing this project'
#synced_folder=$(find $HOME \( ! -regex '.*/\..*' \) -type f -name 'install-bootstrap.sh')
#synced_path=$(dirname "$synced_folder") 
#export SYNCED_PATH="$synced_path"

#source $SYNCED_PATH/scripts/tools/export-var.sh

cd scripts/enrollment
echo "Runinng script enroll-device.sh enp0s8 --remove"
bash enroll-device.sh enp0s8 --remove